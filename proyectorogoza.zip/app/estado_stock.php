<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class estado_stock extends Model
{
    //
}
