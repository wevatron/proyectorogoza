<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Stock extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('stock', function (Blueprint $table) {
            $table->increments('id');
            $table->double('cantidad');
            $table->integer('proveedor_id');
            $table->integer('producto_id');
            $table->double('precio_compra');
            $table->double('precio_venta');
            $table->integer('estado_id'); 
            $table->integer('bodega_id');
            $table->integer('transaccion_id');     
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
